create
    definer = root@localhost procedure transfer_funds(IN id_from int, IN id_to int, IN amount decimal,
                                                      OUT result varchar(255))
begin
    declare send_id int;
    declare to_id int;
    declare from_balance decimal;
    select count(id ) into send_id from  accounts where id=id_from;
    select count(id) into to_id from  accounts where id=id_to;
    select balance into from_balance from accounts where id=id_from;
    if send_id=0 then set  result ='Không tìm thấy người gửi!';
    elseif to_id =0 then set result ='không tìm thấy người nhận !';
    elseif from_balance < amount then set result = 'Người gửi không đủ tiền !' ;
    update accounts set balance = balance - amount where id = id_from ;
    update accounts set balance = balance + amount where id = id_to ;
    set result = 'Chuyển tiền thành công !' ;
    end if ;
end;

