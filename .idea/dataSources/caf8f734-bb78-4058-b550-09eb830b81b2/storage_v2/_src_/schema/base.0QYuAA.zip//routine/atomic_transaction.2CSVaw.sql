create
    definer = root@localhost procedure atomic_transaction(IN fromAccountid int, IN toaccountid int, IN inamount decimal(10, 2))
begin 
declare balance_sender decimal(10,2) default 0;
declare insert_id bigint;
start transaction ;
update accounts 
set balance = balance + inamount where  accountID=toAccountid;
update accounts 
set balance = balance - inamount where  accountID=fromAccountid ;

select balance into balance_sender from accounts  where accountid =fromAccountid ;
if balance_sender<0 then rollback;
else insert into transactions(fromaccountid,toaccountid,amount,transactiondate)
value (fromaccountid,toaccountid,inamount,now());
set insert_id= last_insert_id();
insert into expenses (accountid,amount,expensedate,description) values 
(fromaccountid,amount,now(),'send money');
update budgets
set amount = amount-inamount
where accountid=fromaccountid;
insert into transactionhistory(transactionid,accountid,amount,transactiondate,type)
value (insert_id,fromaccountid,inamount,now(),'send'),
(insert_id,toaccountid,inamount,now(),'recieved');
commit;
end if ;
end;

